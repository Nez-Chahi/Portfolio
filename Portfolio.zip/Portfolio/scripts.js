document.addEventListener('DOMContentLoaded', function() {
    var tablinks = document.getElementsByClassName("tab-links");
    var tabcontents = document.getElementsByClassName("tab-contents");

    // Add event listeners to tab links
    for (var i = 0; i < tablinks.length; i++) {
        tablinks[i].addEventListener('click', function() {
            // Remove active class from all tab links and contents
            for (var j = 0; j < tablinks.length; j++) {
                tablinks[j].classList.remove("active-link");
                tabcontents[j].classList.remove("active-tab");
            }

            // Add active class to clicked tab link and corresponding content
            this.classList.add("active-link");
            var tabName = this.textContent.toLowerCase();
            
            // Map tab text to corresponding tab contents
            var tabMap = {
                'compétences': 'compétences',
                'expériences': 'expériences',
                'education': 'education'
            };

            document.getElementById(tabMap[tabName]).classList.add("active-tab");
        });
    }

    const navbar = document.getElementById("nav-bar");
    const navLinks = document.querySelectorAll('.header-nav-list a');

    navLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            const navbarHeight = navbar.offsetHeight;
            const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
            const offsetPosition = targetPosition - navbarHeight;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        });
    });

    window.addEventListener("scroll", () => {
        if (window.scrollY > 0) {
            navbar.classList.add("scrolled");
        } else {
            navbar.classList.remove("scrolled");
        }
    });

    var typed = new Typed('.typed-text', {
        strings: ['Frontend Developer', 'UX Designer', 'Backend Developer', 'App Designer'],
        typeSpeed: 70,
        backSpeed: 50,
        loop: true
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const goTopBtn = document.querySelector('.go-top-btn');

    
    goTopBtn.style.zIndex = '1000';
    
    
    goTopBtn.style.border = 'none';
    goTopBtn.style.outline = 'none';
    
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 500) {
            goTopBtn.style.display = 'flex';
            goTopBtn.style.opacity = '1';
        } else {
            goTopBtn.style.display = 'none';
            goTopBtn.style.opacity = '0';
        }
    });

    
    goTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});

